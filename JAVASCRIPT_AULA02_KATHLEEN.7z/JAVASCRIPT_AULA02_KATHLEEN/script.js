function mostraData() {
    document.getElementById("data").innerHTML = Date();
}
function mostraMensagem() {
    alert("Estou apresendo a programar em JavaScript!")
}